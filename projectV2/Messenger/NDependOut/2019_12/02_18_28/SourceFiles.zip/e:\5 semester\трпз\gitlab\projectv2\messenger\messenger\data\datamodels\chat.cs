﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Messenger.Data.DataModels
{
    public class Chat
    {
        [Key]
        public int ChatId { get; set; }
        public string ChatType { get; set; }
        public string ChatStatus { get; set; }
        public int? ChatAdminId { get; set; }
        public string ChatImg { get; set; }
        public string ChatName { get; set; }

        public ICollection<UserInChat> UserInChats { get; set; }
    }
}
